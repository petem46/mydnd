@extends('layouts.app')

@section('content')
<div class="container">
    <app></app>
</div>
@endsection
