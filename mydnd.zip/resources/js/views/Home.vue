<template>
  <p>This is the homepage</p>
</template>
<script>
    export default {
        mounted() {
            console.log('Home Page Loaded.')
        },

    }
</script>
