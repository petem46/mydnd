<template>
  <p>Campaigns Page</p>
</template>
<script>
    export default {
        mounted() {
            console.log('Campaign List Loaded.')
        },

    }
</script>
